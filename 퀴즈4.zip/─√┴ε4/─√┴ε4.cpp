﻿#include<bangtal.h>
#include<stdlib.h>
#include <time.h>


SceneID scene1, scene2;
ObjectID startbutton, broad[4][4];
ObjectID puzzle1, puzzle2, puzzle3, puzzle4, puzzle5, puzzle6, puzzle7, puzzle8;
ObjectID puzzle9, puzzle10, puzzle11, puzzle12, puzzle13, puzzle14, puzzle15, puzzle16;
TimerID timer1, timer2;

int puzzleX[4][4], puzzleY[4][4], clear[4][4];
bool shown[4][4], restart = false;


void locateObject(ObjectID object, SceneID scene, int x, int y, bool shown) {

	locateObject(object, scene, x, y);

	if (shown) {
		showObject(object);
	}
	else if(shown == false){
		hideObject(object);
	}
}

ObjectID createObject(const char* name, SceneID scene, int x, int y) {
	ObjectID object = createObject(name);

	broad[y][x] = object;
	locateObject(broad[y][x], scene, puzzleX[y][x], puzzleY[y][x], shown[y][x]);

	return object;
}

void clearCheck() {

	int save = 1;
	bool save2 = true;

	for (int y = 0; y < 4; y++) {
		for (int x = 0; x < 4; x++) {
			if (clear[x][y] == save) {
				save++;
			
			}else {
				save2 = false;
				break;
			}
		}

		if (save2 == false) {
			break;
		}
	}

	if (save == 17) {
		enterScene(scene1);
		stopTimer(timer1);
		
		restart = false;
		setObjectImage(startbutton, "start.png");
		locateObject(startbutton, scene1, 150, 360);

	}
}

void change(int r3, int r4, int r1, int r2) {

	bool saveS = shown[r3][r4];
	ObjectID save = broad[r3][r4];
	int saveC = clear[r3][r4];

	shown[r3][r4] = shown[r1][r2];
	broad[r3][r4] = broad[r1][r2];
	clear[r3][r4] = clear[r1][r2];

	shown[r1][r2] = saveS;
	broad[r1][r2] = save;
	clear[r1][r2] = saveC;

	locateObject(broad[r3][r4], scene2, puzzleX[r3][r4], puzzleY[r3][r4], shown[r3][r4]);
	locateObject(broad[r1][r2], scene2, puzzleX[r1][r2], puzzleY[r1][r2]), shown[r1][r2];
}

void randPuzzle() {

	srand((unsigned)time(NULL));
	int rand_num = rand() % 20+10;

	for (int i = 0; i < rand_num; i++) {

		int r3 = rand() % 4;
		int r4 = rand() % 4;

		int r1 = rand() % 4;
		int r2 = rand() % 4;

		change(r3, r4, r1, r2);
	}

}

void gameSet() {

	int valueX;
	int valueY = 460;
	int valueC = 1;

	for (int y = 0; y < 4; y++) {
		valueX = 440;
		for (int x = 0; x < 4; x++) {

			shown[x][y] = true;

			puzzleX[x][y] = valueX;
			puzzleY[x][y] = valueY;

			clear[x][y] = valueC;
			valueC++;

			valueX = valueX + 100;
		}		
		valueY = valueY - 100;
	}

	srand((unsigned)time(NULL));
	int bX = rand() % 4;
	int bY = rand() % 4;

	shown[bX][bY] = false;

}

void timer() {

	timer1 = createTimer(1.0f);
	timer2 = createTimer(0.0f);
	showTimer(timer2);
	startTimer(timer1);

}

void move(int x, int y) {

	if ((x<3) && (shown[x+1][y] == false)) {
		change(x+1, y, x, y);
	}else if ((x>0) && (shown[x-1][y] == false)) {
		change(x-1, y, x, y);
	}else if ((y < 3) && (shown[x][y+1] == false)) {
		change(x, y+1, x, y);
	}else if ((y > 0) && (shown[x][y-1] == false)) {
		change(x, y-1, x, y);
	}
		
	
}

void mouseCallBack(ObjectID object, int X1, int Y1, MouseAction action) {

	if (object == startbutton) {

		if (restart == false) {
			enterScene(scene2);
			randPuzzle();
			timer();

			setObjectImage(startbutton, "restart.png");
			locateObject(startbutton, scene2, 150, 360);

			restart = true;
		}
		else if (restart == true) {
			randPuzzle();
			timer();
		}
	}else{

		int exit = 0;

		for (int y = 0; y < 4; y++) {
			for (int x = 0; x < 4; x++) {
				if (object == broad[x][y]) {

					if (shown[x][y] == true) {
						move(x, y);

						exit = 1;
						break;
					}
				}
			}

			if (exit == 1) {
				break;
			}
		}
		clearCheck();
	}
}

void timerCallBack(TimerID timer) {
	if (timer == timer1) {
		setTimer(timer1, 1.0f);
		increaseTimer(timer2, 1.0f);
		startTimer(timer1);
	}
}

int main() {

	setMouseCallback(mouseCallBack);
	setTimerCallback(timerCallBack);
	gameSet();

	scene1 = createScene("토토로", "토토로1.png");
	scene2 = createScene("토토로", "토토로 배경1.png");

	startbutton = createObject("start.png");
	locateObject(startbutton, scene1, 150, 360);
	showObject(startbutton);


	puzzle1 = createObject("토토러1-1.png", scene2, 0,0);
	puzzle2 = createObject("토토러1-2.png", scene2, 0,1);
	puzzle3 = createObject("토토러1-3.png", scene2, 0,2);
	puzzle4 = createObject("토토러1-4.png", scene2, 0,3);
	
	puzzle5 = createObject("토토러2-1.png", scene2, 1,0);
	puzzle6 = createObject("토토러2-2.png", scene2, 1,1);
	puzzle7 = createObject("토토러2-3.png", scene2, 1,2);
	puzzle8 = createObject("토토러2-4.png", scene2, 1,3);

	puzzle9 = createObject("토토러3-1.png", scene2, 2,0);
	puzzle10 = createObject("토토러3-2.png", scene2, 2,1);
	puzzle11 = createObject("토토러3-3.png", scene2, 2,2);
	puzzle12 = createObject("토토러3-4.png", scene2, 2,3);
	
	puzzle13 = createObject("토토러4-1.png", scene2, 3,0);
	puzzle14 = createObject("토토러4-2.png", scene2, 3,1);
	puzzle15 = createObject("토토러4-3.png", scene2, 3,2);
	puzzle16 = createObject("토토러4-4.png", scene2, 3,3);
	
	
	startGame(scene1);

}
